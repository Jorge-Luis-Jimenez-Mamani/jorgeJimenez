package ar.edu.centro8.daw.proyectoFinal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import lombok.Data;

@Entity
@Table(name = "huespedes")
@Data
public class Huespedes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_huesped;

    private String nombre;
    private String apellido;
    private String correo;
    private String telefono;
}


