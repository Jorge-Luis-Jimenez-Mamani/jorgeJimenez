package ar.edu.centro8.daw.proyectoFinal.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

import lombok.RequiredArgsConstructor;

import ar.edu.centro8.daw.proyectoFinal.model.Huespedes;        
import ar.edu.centro8.daw.proyectoFinal.repository.HuespedesRepository; 

@RestController
@RequestMapping("/api/huespedes")
@RequiredArgsConstructor
public class HuespedesController {

    private final HuespedesRepository repository;

    @GetMapping
    public List<Huespedes> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Huespedes crear(@RequestBody Huespedes h) {
        return repository.save(h);
    }
}






