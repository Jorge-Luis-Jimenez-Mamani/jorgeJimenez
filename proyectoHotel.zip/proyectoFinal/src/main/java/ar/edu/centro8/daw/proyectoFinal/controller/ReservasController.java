package ar.edu.centro8.daw.proyectoFinal.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import lombok.RequiredArgsConstructor;

import java.util.List;

import ar.edu.centro8.daw.proyectoFinal.model.Reservas;
import ar.edu.centro8.daw.proyectoFinal.repository.ReservasRepository;
import ar.edu.centro8.daw.proyectoFinal.service.ReservasService;

@RestController
@RequestMapping("/api/reservas")
@RequiredArgsConstructor
public class ReservasController {

    private final ReservasService reservaService;
    private final ReservasRepository reservaRepository;

    @GetMapping
    public List<Reservas> listar() {
        return reservaRepository.findAll();
    }

    @PostMapping
    public Reservas crear(@RequestBody Reservas reserva) {
        return reservaService.crearReserva(reserva);
    }
}

