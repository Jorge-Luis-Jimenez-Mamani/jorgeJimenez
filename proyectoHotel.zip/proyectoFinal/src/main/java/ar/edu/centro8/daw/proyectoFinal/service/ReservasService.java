package ar.edu.centro8.daw.proyectoFinal.service;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import ar.edu.centro8.daw.proyectoFinal.model.Reservas;
import ar.edu.centro8.daw.proyectoFinal.model.Habitaciones;
import ar.edu.centro8.daw.proyectoFinal.repository.ReservasRepository;
import ar.edu.centro8.daw.proyectoFinal.repository.HabitacionesRepository;

@Service
@RequiredArgsConstructor
public class ReservasService {

    private final ReservasRepository reservaRepository;
    private final HabitacionesRepository habitacionRepository;

    public Reservas crearReserva(Reservas reserva) {

        Habitaciones hab = habitacionRepository.findById(reserva.getHabitacion().getId_habitacion())
                .orElseThrow(() -> new RuntimeException("Habitación no encontrada"));

        // Regla de negocio 1: habitación disponible
        if (!hab.getDisponibilidad()) {
            throw new RuntimeException("Habitación no disponible");
        }

        // Regla de negocio 2: fechas correctas
        if (reserva.getFecha_salida().isBefore(reserva.getFecha_entrada())) {
            throw new RuntimeException("La fecha de salida debe ser posterior a la entrada");
        }

        // Marcar habitación como no disponible
        hab.setDisponibilidad(false);
        habitacionRepository.save(hab);

        reserva.setEstado_reserva("CONFIRMADA");
        return reservaRepository.save(reserva);
    }
}

