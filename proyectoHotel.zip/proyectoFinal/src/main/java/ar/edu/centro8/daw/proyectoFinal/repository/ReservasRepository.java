package ar.edu.centro8.daw.proyectoFinal.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.daw.proyectoFinal.model.Reservas;

public interface ReservasRepository extends JpaRepository<Reservas, Long> {

    List<Reservas> findByEstadoReserva(String estado);

    List<Reservas> findByFechaEntradaBetween(LocalDate inicio, LocalDate fin);
}


