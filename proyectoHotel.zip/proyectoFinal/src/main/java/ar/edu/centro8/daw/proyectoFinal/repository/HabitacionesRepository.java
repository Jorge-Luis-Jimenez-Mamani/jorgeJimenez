package ar.edu.centro8.daw.proyectoFinal.repository;

public class HabitacionesRepository {

}
