package ar.edu.centro8.daw.proyectoFinal.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

import java.util.List;

import ar.edu.centro8.daw.proyectoFinal.model.Habitaciones;
import ar.edu.centro8.daw.proyectoFinal.repository.HabitacionesRepository;

@RestController
@RequestMapping("/api/habitaciones")
@RequiredArgsConstructor
public class HabitacionesController {

    private final HabitacionesRepository repository;

    @GetMapping
    public List<Habitaciones> listar() {
        return repository.findAll();
    }

    @GetMapping("/disponibles")
    public List<Habitaciones> disponibles() {
        return repository.findByDisponibilidad(true);
    }
}
