package ar.edu.centro8.daw.proyectoFinal.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;

import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "reservas")
@Data
public class Reservas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_reserva;

    @ManyToOne
    @JoinColumn(name = "id_huesped")
    private Huespedes huesped;

    @ManyToOne
    @JoinColumn(name = "id_habitacion")
    private Habitaciones habitacion;

    private LocalDate fecha_entrada;
    private LocalDate fecha_salida;
    private String estado_reserva;
}

