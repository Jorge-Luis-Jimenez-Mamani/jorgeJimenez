// Detecta cuando el mouse pasa por un enlace
document.querySelectorAll('#lista a').forEach((enlace) => {
    enlace.addEventListener('mouseover', () => {
        const imagen = enlace.getAttribute('data-img');
        document.getElementById("preview").src = imagen;
    });
});
