function mostrar() {
    document.getElementById("miDiv").style.display = "block";
}

function ocultar() {
    document.getElementById("miDiv").style.display = "none";
}