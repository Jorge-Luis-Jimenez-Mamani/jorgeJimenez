const mensaje = document.getElementById("mensaje");
const enlaces = document.querySelectorAll(".hover-text");

// Cambiar el texto al pasar el cursor
enlaces.forEach(enlace => {
    enlace.addEventListener("mouseenter", () => {
        mensaje.textContent = enlace.dataset.texto;
    });

    enlace.addEventListener("mouseleave", () => {
        mensaje.textContent = "otro texto";
    });
});
