function mostrarHora() {
    // Instanciar la hora actual
    let reloj = new Date();

    // Obtener horas, minutos y segundos
    let horas = reloj.getHours();
    let minutos = reloj.getMinutes();
    let segundos = reloj.getSeconds();

    // Formatear (opcional) para que aparezcan con 2 dígitos
    if (horas < 10) horas = "0" + horas;
    if (minutos < 10) minutos = "0" + minutos;
    if (segundos < 10) segundos = "0" + segundos;

    // Mostrar en el div
    document.getElementById("hora").innerHTML = 
    horas + ":" + minutos + ":" + segundos;
}

function iniciarReloj() {
    mostrarHora(); // mostrar inmediatamente
    window.setInterval('mostrarHora()', 1000); // actualizar cada segundo
}