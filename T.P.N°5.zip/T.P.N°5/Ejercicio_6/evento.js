function cambiar() {
    let texto = document.getElementById("toggleText");
    let div = document.getElementById("miDiv");

    if (texto.innerHTML === "Mostrar Div") {
        texto.innerHTML = "Ocultar Div";
        div.style.display = "block";
    } else {
        texto.innerHTML = "Mostrar Div";
        div.style.display = "none";
    }
}