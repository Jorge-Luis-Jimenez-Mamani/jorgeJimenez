// Seleccionamos todas las celdas de la primera fila
const celdasPrimeraFila = document.querySelectorAll('#fila1 td');

celdasPrimeraFila.forEach(celda => {
    celda.addEventListener('click', () => {
        // Primero quitamos la clase 'selected' de todas las celdas de la primera fila
        celdasPrimeraFila.forEach(c => c.classList.remove('selected'));
        // Agregamos la clase 'selected' solo a la celda clickeada
        celda.classList.add('selected');
    });
});
