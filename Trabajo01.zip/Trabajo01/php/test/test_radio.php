<?php ini_set('display_errors',1) ?>

<!-- http://localhost/objetos/Trabajo01/php/test/test_radio.php -->
<?php 
require_once '../entities/radio.php';
require_once '../entities/vehiculo.php';
require_once '../entities/auto_nuevo.php';
require_once '../entities/auto_clasico.php';
require_once '../entities/colectivo.php';
echo " -- Test de Radio --<br>";
$radio1 = new Radio("JVL", 100);
echo $radio1 ."<br>";

$radio2 = new Radio("PIONEER", 80);
echo $radio2."<br>";

echo "---------------------------------<br>";

echo " -- Test Auto Nuevo --<br>";
echo " -- Auto Nuevo con Radio--<br>";
$auto_nuevo1 = new Auto_Nuevo('rojo', 'TOYOTA', 'Corolla', 30000,$radio1);
echo $auto_nuevo1. "<br>";

echo "-- Se le cambia la radio a, Auto Nuevo --<br>";
$auto_nuevo1->cambiarRadio('Sony',100);
echo $auto_nuevo1."<br>";


echo "--------------------------------<br>";

echo " -- Test Auto Clasico --<br>";
echo "-- Auto Clasico sin radio--<br>";
$auto_clasico = new Auto_Clasico('Azul', 'FORT', 'Mustang', 3000000);
echo $auto_clasico."<br>";

echo "Se le agrega una radio a, Auto Clasico--<br>";
$auto_clasico->agregarRadio('Panasonic', 80);
echo $auto_clasico."<br>";

echo "--------------------------------<br>";

echo "-- Test Colectivo --<br> ";
echo "-- Colectivo sin radio--<br>";
$colectivo = new Colectivo('Amarillo', 'MERCEDES', 'Sprinter', 400000);
echo $colectivo."<br>";

echo "Se le agrega una radio a, Colectivo--<br>";
$colectivo->agregarRadio('Alpine', 110);
echo $colectivo."<br>";


?>