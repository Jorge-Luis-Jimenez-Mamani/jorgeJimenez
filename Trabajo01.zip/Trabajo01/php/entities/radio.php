<?php
class Radio{
    private $marca;
    private $potencia;
    public function __construct( String $marca, int $potencia){
        $this->marca=$marca;
        $this->potencia=$potencia;
    }

    public function __toString(): string{
        return  $this->marca.", ".$this->potencia." watts";
    }
    
 
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    public function __set($property, $value){
       
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>