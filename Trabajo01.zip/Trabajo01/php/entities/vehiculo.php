<?php 
require_once "../entities/radio.php";
abstract class Vehiculo{
    private $color;
    private $marca;
    private $modelo;
    private $radio;
    private $precio;
    public function __construct (String $color, String $marca, String $modelo, int $precio = null, Radio $radio = null){
        $this->color=$color;
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->precio=$precio;
        $this->radio=$radio;
    }

    public function agregarRadio( String $marca, int $potencia){

        
        $this->radio=new Radio($marca, $potencia);
        
    }

    public function cambiarRadio(String $marca, int $potencia){

       
        $this->radio=new Radio($marca, $potencia);
    }

    public function __toString(): string{
        return  $this->color.", ".$this->marca.", ".
                $this->modelo.", ".$this->radio.", ".
                $this->precio;
    }

   
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

   
    public function __set($property, $value){
        
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>