<?php 
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";

class Auto_Clasico extends Vehiculo{
    public function __construct(String $color, String $marca, String $modelo, int $precio ){
        parent::__construct($color, $marca, $modelo,    $precio);
    }  

    public function __toString(): string{
        return  $this->color.", ".$this->marca.", ".
                $this->modelo.", ".$this->radio.", ".
                $this->precio;
    }
}
?>