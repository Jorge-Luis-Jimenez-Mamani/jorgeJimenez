<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $peso = $_POST["peso"];
    $altura = $_POST["altura"];

    // Calcular IMC
    $imc = calcularIMC($peso, $altura);

    // Determinar el estado
    $estado = determinarEstado($imc);

    // Mostrar el resultado
    echo "<hr>";
    echo "<p class='text-center'><strong>IMC: </strong>" . number_format($imc, 2) . "</p>";
    echo "<p class='text-center'><strong>Estado: </strong>" . $estado . "</p>";
}



// Función para calcular el IMC
function calcularIMC($peso, $altura) {
    return $peso / ($altura * $altura);
}

// Función para determinar el estado según el IMC
function determinarEstado($imc) {
    $estado = "";
    switch (true) {
        case ($imc < 15):
            $estado = "Delgadez muy severa";
            break;
        case ($imc >= 15 && $imc <= 15.9):
            $estado = "Delgadez severa";
            break;
        case ($imc >= 16 && $imc <= 18.4):
            $estado = "Delgadez";
            break;
        case ($imc >= 18.5 && $imc <= 24.9):
            $estado = "Normal";
            break;
        case ($imc >= 25 && $imc <= 29.9):
            $estado = "Sobrepeso";
            break;
        case ($imc >= 30 && $imc <= 34.9):
            $estado = "Obesidad moderada";
            break;
        case ($imc >= 35 && $imc <= 39.9):
            $estado = "Obesidad severa";
            break;
        case ($imc >= 40):
            $estado = "Obesidad mórbida";
            break;
        default:
            $estado = "Error en el cálculo";
            break;
    }
    return $estado;
}

?>






