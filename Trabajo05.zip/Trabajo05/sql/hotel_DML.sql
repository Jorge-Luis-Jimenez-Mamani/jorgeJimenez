-- Insertar registros de la tabla huespedes
insert into huespedes (nombre, apellido, correo, telefono) VALUES
('Juan', 'Pérez', 'juan.perez@example.com', '555-1234'),
('Ana', 'Gómez', 'ana.gomez@example.com', '555-5678'),
('Carlos', 'Sánchez', 'carlos.sanchez@example.com', '555-8765'),
('Lucía', 'Martínez', 'lucia.martinez@example.com', '555-4321'),
('Pedro', 'Rodríguez', 'pedro.rodriguez@example.com', '555-6789'),
('María', 'López', 'maria.lopez@example.com', '555-3456'),
('José', 'González', 'jose.gonzalez@example.com', '555-9876'),
('Claudia', 'Fernández', 'claudia.fernandez@example.com', '555-6543'),
('David', 'Ramírez', 'david.ramirez@example.com', '555-1122'),
('Elena', 'Torres', 'elena.torres@example.com', '555-3344');

-- Insertar registros de la tabla habitaciones
insert into habitaciones (numero, tipo, precio, disponibilidad) VALUES
(101, 'Sencilla', 50.00, true),
(102, 'Doble', 80.00, true),
(103, 'Suite', 150.00, true),
(104, 'Sencilla', 55.00, true),
(105, 'Doble', 90.00, true),
(106, 'Suite', 160.00, true),
(107, 'Sencilla', 60.00, false),
(108, 'Doble', 85.00, true),
(109, 'Suite', 175.00, true),
(110, 'Sencilla', 65.00, true);

-- Insetar registros en la taabla reservas
insert into reservas (id_huesped, id_habitacion, fecha_entrada, fecha_salida, estado_reserva) VALUES
(1, 1, '2024-11-01', '2024-11-05', 'confirmada'),
(2, 2, '2024-11-10', '2024-11-12', 'pendiente'),
(3, 3, '2024-11-15', '2024-11-18', 'confirmada'),
(4, 4, '2024-11-20', '2024-11-22', 'cancelada'),
(5, 5, '2024-11-25', '2024-11-30', 'confirmada'),
(6, 6, '2024-12-01', '2024-12-05', 'pendiente'),
(7, 7, '2024-12-05', '2024-12-07', 'confirmada'),
(8, 8, '2024-12-10', '2024-12-15', 'pendiente'),
(9, 9, '2024-12-12', '2024-12-14', 'confirmada'),
(10, 10, '2024-12-15', '2024-12-18', 'cancelada');


-- Insettar registros de la tabla pagos
insert into pagos (id_reserva, monto, fecha_pago, metodo_pago) VALUES
(1, 250.00, '2024-11-01', 'tarjeta'),
(2, 160.00, '2024-11-10', 'efectivo'),
(3, 450.00, '2024-11-15', 'tarjeta'),
(4, 220.00, '2024-11-20', 'transferencia'),
(5, 270.00, '2024-11-25', 'tarjeta'),
(6, 480.00, '2024-12-01', 'efectivo'),
(7, 120.00, '2024-12-05', 'transferencia'),
(8, 340.00, '2024-12-10', 'tarjeta'),
(9, 525.00, '2024-12-12', 'efectivo'),
(10, 195.00, '2024-12-15', 'transferencia');

