
-- Obtener a todos los huespedes
SELECT * FROM huespedes;

-- Obtener todas las habitaciones disonibles
SELECT * FROM habitaciones WHERE disponibilidad = TRUE;

-- Obtener reserbas confirmadas
SELECT r.id_reserva, h.nombre, h.apellido, ha.numero, r.fecha_entrada, r.fecha_salida, r.estado_reserva
FROM reservas r
JOIN huespedes h ON r.id_huesped = h.id_huesped
JOIN habitaciones ha ON r.id_habitacion = ha.id_habitacion
WHERE r.estado_reserva = 'confirmada';

--  Obtener pagos realizados para una reserva
SELECT p.id_pago, p.monto, p.fecha_pago, p.metodo_pago
FROM pagos p
JOIN reservas r ON p.id_reserva = r.id_reserva
WHERE r.id_reserva = 1;  

-- Obtener el total de pagos realizados por un huésped
SELECT h.nombre, h.apellido, SUM(p.monto) AS total_pagado
FROM pagos p
JOIN reservas r ON p.id_reserva = r.id_reserva
JOIN huespedes h ON r.id_huesped = h.id_huesped
GROUP BY h.id_huesped;

--  Actualizar el estado de una reserva
UPDATE reservas 
SET estado_reserva = 'confirmada' 
WHERE id_reserva = 2;

-- Actualizar la disponibilidad de una habitación
UPDATE habitaciones 
SET disponibilidad = FALSE 
WHERE id_habitacion = 1;



