-- Active: 1732286543126@@127.0.0.1@3306@hotel

drop database if exists Hotel;
create  database Hotel;
use Hotel;

-- Tabla de huespedes
create table huespedes (
    id_huesped int auto_increment primary key,  
    nombre varchar(100) not null,               
    apellido varchar(100) not null,             
    correo varchar(100) unique,                 
    telefono varchar(15)                        
);

-- Tabla de habitaciones
create table habitaciones (
    id_habitacion int auto_increment primary key,  
    numero int not null,                           
    tipo varchar(50),                              
    precio decimal(10, 2) not null,                
    disponibilidad boolean default TRUE         
);

-- Tabla de reservas
create table reservas (
    id_reserva int auto_increment primary key,     
    id_huesped int not null,                        
    id_habitacion int not null,                     
    fecha_entrada date not null,                    
    fecha_salida date not null,                     
    estado_reserva enum('pendiente', 'confirmada', 'cancelada') default 'pendiente', 
    foreign  key(id_huesped) references huespedes(id_huesped) on delete cascade, 
    foreign key (id_habitacion) references habitaciones(id_habitacion) on delete cascade
);

-- Tabla de pagos
create table pagos (
    id_pago int auto_increment primary key,         
    id_reserva int not null,                        
    monto decimal(10, 2) not null,                  
    fecha_pago date not null,                       
    metodo_pago enum('efectivo', 'tarjeta', 'transferencia') not null, 
    foreign key (id_reserva) references reservas(id_reserva) on delete cascade
);