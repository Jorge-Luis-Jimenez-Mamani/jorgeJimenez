// Función para calcular el IMC
function calcularIMC(peso, altura) {
    return peso / (altura * altura);
  }
  
  // Función para determinar el estado según el IMC
  function determinarEstado(imc) {
    let estado = "";
    
    switch (true) {
      case (imc < 15):
        estado = "Delgadez muy severa";
        break;
      case (imc >= 15 && imc <= 15.9):
        estado = "Delgadez severa";
        break;
      case (imc >= 16 && imc <= 18.4):
        estado = "Delgadez";
        break;
      case (imc >= 18.5 && imc <= 24.9):
        estado = "Normal";
        break;
      case (imc >= 25 && imc <= 29.9):
        estado = "Sobrepeso";
        break;
      case (imc >= 30 && imc <= 34.9):
        estado = "Obesidad moderada";
        break;
      case (imc >= 35 && imc <= 39.9):
        estado = "Obesidad severa";
        break;
      case (imc >= 40):
        estado = "Obesidad mórbida";
        break;
      default:
        estado = "Valor inválido";
    }
  
    return estado;
  }
  
  // Función para manejar el envío del formulario
  document.getElementById('imcForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    // Obtener los valores del formulario
    const peso = parseFloat(document.getElementById('peso').value);
    const altura = parseFloat(document.getElementById('altura').value);
  
    // Verificar que los valores son válidos
    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
      alert('Por favor, ingrese valores válidos.');
      return;
    }
  
    // Calcular el IMC
    const imc = calcularIMC(peso, altura);
  
    // Determinar el estado
    const estado = determinarEstado(imc);
  
    // Mostrar el resultado
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.innerHTML = `IMC: ${imc.toFixed(2)}<br>Estado: ${estado}`;
  });