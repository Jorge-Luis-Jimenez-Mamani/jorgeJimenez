<?php ini_set("display_errors","1");  ?>
<?php 
require_once "../interfaces/interfaceConcesionaria.php";
require_once "../entities/auto.php";
require_once "../entities/vehiculo.php";
require_once "../entities/consecionaria.php";
require_once "../entities/moto.php";

http://localhost/objetos/Trabajo02/php/test/test_interface.php 

echo "**** TRABAJO 02 De Interfaces ****<br>";
echo "<br>\n";
echo "-- Test Agregar Vehiculos --<br>";


$auto1 = new Auto("Peugeot", "206", 4, 20000000);
$moto1 = new Moto("Honda", "Titan", 125, 6000000);
$auto2 = new Auto("Peugeot", "208", 5, 25000000);
$moto2 = new Moto("Yamaha", "YBR", 160, 8050050);

$concesionaria = new Concesionaria();


$concesionaria->agregarVehiculo($auto1);

$concesionaria->agregarVehiculo($moto1);

$concesionaria->agregarVehiculo($auto2);

$concesionaria->agregarVehiculo($moto2);


foreach ($concesionaria->getVehiculos( ) as $vehiculos){
     echo $vehiculos."<br>";
}

echo "<br>\n";
echo "=============================<br>";
echo "<br>\n";

$concesionaria -> vehiculoMasCaro();
echo "<br>\n";

$concesionaria ->vehiculoMasBarato();
echo "<br>\n";


$concesionaria -> vehiculoConLaLetraY();

echo "<br>\n";
echo "=============================<br>";
echo "<br>\n";

echo "Vehiculos ordenados por precio de mayor a menor: " . "<br>";
$concesionaria -> precioMayorYMenor();

echo "<br>\n";
echo "=============================<br>";
echo "<br>\n";

echo "Vehículos ordenados por orden natural (marca, modelo, precio): " . "<br>";
$concesionaria -> ordenadosPorOrdenNatural();
?>