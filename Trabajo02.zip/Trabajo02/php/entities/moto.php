<?php 
require_once "../entities/vehiculo.php";


class Moto extends Vehiculo {
private $cilindrada;

public function __construct(string $marca, string $modelo, int $cilindrada, int $precio){
    parent::__construct($marca, $modelo, $precio);
    $this->cilindrada = $cilindrada;
}

         
      
public function __toString(): string {
    return "Marca: " . $this->getMarca() . " // Modelo: " . $this->getModelo() . " // Cilindrada: " . $this->cilindrada ."c". " // Precio: \$" . $this->getPrecio();
}



}
?>