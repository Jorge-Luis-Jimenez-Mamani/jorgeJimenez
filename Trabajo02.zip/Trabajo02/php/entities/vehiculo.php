<?php
 abstract class Vehiculo
{
    private $marca;
    private $modelo;
    private $precio;

    public function __construct(string $marca, string $modelo, float $precio)
    {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
    }

    
    public function getMarca(): string
    {
        return $this->marca;
    }

    public function getModelo(): string
    {
        return $this->modelo;
    }

    public function getPrecio(): int
    {
        return $this->precio;
    }

}
?>