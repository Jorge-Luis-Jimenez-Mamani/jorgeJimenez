<?php
require_once "../entities/vehiculo.php";


class Auto extends Vehiculo
{
    private $puertas;

    public function __construct(string $marca, string $modelo, int $puertas, float $precio)
    {
        parent::__construct($marca, $modelo, $precio);
        $this->puertas = $puertas;
    }




    public function __toString(): string
    {
        return "Marca: " . $this->getMarca() . " // Modelo: " . $this->getModelo() . " // Puertas: " . $this->puertas . " // Precio: \$" . $this->getPrecio( );  
    }


}



?>