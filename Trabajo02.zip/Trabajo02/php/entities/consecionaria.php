<?php
require_once "../interfaces/interfaceConcesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";

class Concesionaria implements InteterfaceConcesionaria{
    
private array $vehiculos = [];


public function __construct(array $vehiculos = [] ){
      
    $this->vehiculos = $vehiculos;
           
} 
    
// Metodo para agregar vehiculos a Concesionaria
public function agregarVehiculo( Vehiculo $vehiculo):void{
    $this->vehiculos[] = $vehiculo;    

}

public function getVehiculos(): array {
    return $this->vehiculos;
}

// Metodo para saver cual es el vehiculo mas caro
public function vehiculoMasCaro()
{
    $concesionaria = $this->vehiculos[0];
    foreach ($this->vehiculos as $vehiculo) {
        if ($vehiculo->getPrecio() > $concesionaria->getPrecio()) {
            $concesionaria = $vehiculo;
        }
    }

   echo "Vehiculo mas caro es: " . $concesionaria->getMarca() . " " . $concesionaria->getModelo();
   
}


// Metodo para saver el vehiculo mas barato
public function vehiculoMasBarato()
{
    $concesionaria = $this->vehiculos[0];
    foreach ($this->vehiculos as $vehiculo) {
        if ($vehiculo->getPrecio() < $concesionaria->getPrecio()) {
            $concesionaria = $vehiculo;
        }
    }
    echo "Vehiculo mas barato es: " . $concesionaria->getMarca() . " " . $concesionaria->getModelo();
    
}

// Metodo que modelo contiene la letra Y
public function vehiculoConLaLetraY()
{
    foreach ($this->vehiculos as $vehiculo) {
        if (strpos($vehiculo->getModelo(), 'Y') !== false) {
            
            echo "Vehiculo que contiene en el modelo la letra 'Y': " . $vehiculo->getMarca() . " " . $vehiculo->getModelo() . " $" . $vehiculo->getPrecio();
           
        }
    }
}

//Metodo que ordena el precio de mayor a menor
public function precioMayorYMenor()
    {
    usort($this->vehiculos, function ($a, $b) {
        return $b->getPrecio() <=> $a->getPrecio();
    });
       
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo->getMarca() . " " . $vehiculo->getModelo();
            echo "<br>\n"; 
        }
}


//Metodo que ordena los vehiculos por orden natural       
public function ordenadosPorOrdenNatural()
    {
    usort($this->vehiculos, function ($a, $b) {
        return [$a->getMarca(), $a->getModelo()] <=> [$b->getMarca(), $b->getModelo()];
    });
        
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo;
            echo "<br>\n"; 
        }

    }


}    

?>