<?php

interface InteterfaceConcesionaria{

function agregarVehiculo(Vehiculo $vehiculo);

function vehiculoMasCaro();

function vehiculoMasBarato();

function vehiculoConLaLetraY();

function precioMayorYMenor();

function ordenadosPorOrdenNatural();


}
?>